"""
Feature engineering: Elo (global + surface), rolling form, head-to-head with Bayesian smoothing.
All computations are chronological (no lookahead).
"""
from __future__ import annotations

from collections import defaultdict, deque
import numpy as np
import pandas as pd

BASE_ELO = 1500
K_BASE = 32

# Version tag for the online Elo in this module (reproducibility / write-up).
ELO_SPEC_ID = "online_K32_base1500_surface_v1"


def add_elo_spec_column(matches: pd.DataFrame, spec_id: str = ELO_SPEC_ID) -> pd.DataFrame:
    """Attach constant elo_spec_id for metadata (not used as a model feature by default)."""
    out = matches.copy()
    out["elo_spec_id"] = spec_id
    return out


def expected_score(r_a: float, r_b: float) -> float:
    return 1.0 / (1.0 + 10 ** ((r_b - r_a) / 400.0))


class EloTracker:
    def __init__(self, base: float = BASE_ELO, K: float = K_BASE, surfaces=( "hard", "clay", "grass", "other" )):
        self.base = base
        self.K = K
        self.ratings = defaultdict(lambda: base)
        self.surface_ratings = {s: defaultdict(lambda: base) for s in surfaces}

    def get(self, player: str, surface: str | None = None) -> float:
        if surface is None:
            return self.ratings[player]
        return self.surface_ratings.get(surface, {}).get(player, self.base)

    def update(self, winner: str, loser: str, surface: str | None = None) -> None:
        Rw = self.ratings[winner]
        Rl = self.ratings[loser]
        Ew = expected_score(Rw, Rl)
        El = 1 - Ew
        self.ratings[winner] = Rw + self.K * (1 - Ew)
        self.ratings[loser] = Rl + self.K * (0 - El)
        if surface in self.surface_ratings:
            Rs_w = self.surface_ratings[surface][winner]
            Rs_l = self.surface_ratings[surface][loser]
            Es_w = expected_score(Rs_w, Rs_l)
            Es_l = 1 - Es_w
            self.surface_ratings[surface][winner] = Rs_w + self.K * (1 - Es_w)
            self.surface_ratings[surface][loser] = Rs_l + self.K * (0 - Es_l)


def add_elo_features(matches: pd.DataFrame) -> pd.DataFrame:
    """Add elo_before_w, elo_before_l, elo_surf_before_w, elo_surf_before_l to matches (chronological)."""
    elo_tracker = EloTracker()
    elo_before_w, elo_before_l = [], []
    elo_surf_before_w, elo_surf_before_l = [], []

    for _, row in matches.iterrows():
        w = row["winner_name"]
        l = row["loser_name"]
        surf = row.get("surface", "other")
        if pd.isna(surf):
            surf = "other"
        elo_before_w.append(elo_tracker.get(w))
        elo_before_l.append(elo_tracker.get(l))
        elo_surf_before_w.append(elo_tracker.get(w, surf))
        elo_surf_before_l.append(elo_tracker.get(l, surf))
        elo_tracker.update(w, l, surf)

    out = matches.copy()
    out["elo_before_w"] = elo_before_w
    out["elo_before_l"] = elo_before_l
    out["elo_surf_before_w"] = elo_surf_before_w
    out["elo_surf_before_l"] = elo_surf_before_l
    return out


def add_rolling_features(matches: pd.DataFrame, K: int = 8) -> pd.DataFrame:
    """Add form_w, form_l, surf_form_w, surf_form_l, days_since_w, days_since_l (last K matches)."""
    rows = []
    for _, r in matches.iterrows():
        d = r["tourney_date"]
        surf = r["surface"]
        rows.append({"player": r["winner_name"], "opponent": r["loser_name"], "did_win": 1, "date": d, "surface": surf})
        rows.append({"player": r["loser_name"], "opponent": r["winner_name"], "did_win": 0, "date": d, "surface": surf})
    player_history = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)

    recent_results = defaultdict(lambda: deque(maxlen=K))
    recent_dates = defaultdict(lambda: deque(maxlen=K))
    surface_history = defaultdict(lambda: defaultdict(lambda: deque(maxlen=K)))

    player_history["last_k_winrate"] = np.nan
    player_history["last_k_surface_winrate"] = np.nan
    player_history["days_since_last"] = np.nan

    for idx, row in player_history.iterrows():
        p = row["player"]
        d = row["date"]
        s = row["surface"]
        last_results = list(recent_results[p])
        player_history.at[idx, "last_k_winrate"] = np.mean(last_results) if last_results else 0.5
        surf_res = list(surface_history[p][s])
        player_history.at[idx, "last_k_surface_winrate"] = np.mean(surf_res) if surf_res else 0.5
        if recent_dates[p]:
            player_history.at[idx, "days_since_last"] = (d - recent_dates[p][-1]).days
        else:
            player_history.at[idx, "days_since_last"] = np.nan
        recent_results[p].append(row["did_win"])
        recent_dates[p].append(d)
        surface_history[p][s].append(row["did_win"])

    ph_feats = {}
    for idx, r in player_history.iterrows():
        key = (r["player"], r["date"])
        ph_feats[key] = {
            "last_k_winrate": r["last_k_winrate"],
            "last_k_surface_winrate": r["last_k_surface_winrate"],
            "days_since_last": r["days_since_last"],
        }

    form_w, form_l = [], []
    surf_form_w, surf_form_l = [], []
    days_w, days_l = [], []
    for _, r in matches.iterrows():
        d = r["tourney_date"]
        w, l = r["winner_name"], r["loser_name"]
        f = ph_feats.get((w, d), {})
        form_w.append(f.get("last_k_winrate", 0.5))
        surf_form_w.append(f.get("last_k_surface_winrate", 0.5))
        days_w.append(f.get("days_since_last", np.nan))
        f = ph_feats.get((l, d), {})
        form_l.append(f.get("last_k_winrate", 0.5))
        surf_form_l.append(f.get("last_k_surface_winrate", 0.5))
        days_l.append(f.get("days_since_last", np.nan))

    out = matches.copy()
    out["form_w"] = form_w
    out["form_l"] = form_l
    out["surf_form_w"] = surf_form_w
    out["surf_form_l"] = surf_form_l
    out["days_since_w"] = days_w
    out["days_since_l"] = days_l
    return out


def _h2h_key(p1: str, p2: str) -> tuple[str, str]:
    return (min(p1, p2), max(p1, p2))


def add_h2h_features(
    matches: pd.DataFrame,
    prior_weight: float = 3.0,
    prior_win_rate: float = 0.5,
) -> pd.DataFrame:
    """
    Add head-to-head win rate (Bayesian smoothed) for winner and loser as of before each match.
    Columns: h2h_winrate_w, h2h_winrate_l (focal player's win rate vs opponent in past H2H).
    """
    # (p1, p2) -> (wins_by_p1, total) for p1 < p2
    h2h_wins: dict[tuple[str, str], int] = defaultdict(int)
    h2h_total: dict[tuple[str, str], int] = defaultdict(int)

    h2h_w_list = []
    h2h_l_list = []

    for _, row in matches.iterrows():
        w = row["winner_name"]
        l = row["loser_name"]
        key = _h2h_key(w, l)
        # Winner's win rate vs loser (from winner's perspective: wins vs this opponent)
        wins_w = h2h_wins[key] if key[0] == w else (h2h_total[key] - h2h_wins[key])
        total = h2h_total[key]
        rate_w = (prior_win_rate * prior_weight + wins_w) / (prior_weight + total) if (prior_weight + total) > 0 else prior_win_rate
        # Loser's win rate vs winner
        wins_l = h2h_wins[key] if key[0] == l else (h2h_total[key] - h2h_wins[key])
        rate_l = (prior_win_rate * prior_weight + wins_l) / (prior_weight + total) if (prior_weight + total) > 0 else prior_win_rate
        h2h_w_list.append(rate_w)
        h2h_l_list.append(rate_l)
        # Update after match: key is (min,max); if winner < loser then wins for key[0] increase
        h2h_total[key] += 1
        if key[0] == w:
            h2h_wins[key] += 1

    out = matches.copy()
    out["h2h_winrate_w"] = h2h_w_list
    out["h2h_winrate_l"] = h2h_l_list
    return out


def build_diff_dataset(
    matches: pd.DataFrame,
    include_h2h: bool = True,
    *,
    include_elo_levels: bool = True,
    include_player_ids: bool = True,
) -> tuple[pd.DataFrame, list[str]]:
    """
    Build match-difference dataset (one row per match + mirrored row).
    Player A is the focal side: first row has A=winner, B=loser; mirror swaps A/B and flips label.

    When include_elo_levels, adds pre-match elo_a/elo_b and elo_surf_a/elo_surf_b (match-specific).
    When include_player_ids, adds player_a_id/player_b_id (int; use as LightGBM categoricals).

    Returns (df_model with label, list of feature names).
    """
    pair_keys = ("elo_a", "elo_b", "elo_surf_a", "elo_surf_b", "player_a_id", "player_b_id")

    def build_diff_row(row: pd.Series) -> dict:
        feats: dict = {
            "elo_diff": row["elo_before_w"] - row["elo_before_l"],
            "elo_surf_diff": row["elo_surf_before_w"] - row["elo_surf_before_l"],
            "form_diff": row["form_w"] - row["form_l"],
            "surf_form_diff": row["surf_form_w"] - row["surf_form_l"],
            "days_since_diff": (row["days_since_w"] if pd.notna(row["days_since_w"]) else 0)
            - (row["days_since_l"] if pd.notna(row["days_since_l"]) else 0),
            "is_hard": 1 if row["surface"] == "hard" else 0,
            "is_clay": 1 if row["surface"] == "clay" else 0,
            "is_grass": 1 if row["surface"] == "grass" else 0,
            "label": 1,
        }
        if include_elo_levels:
            feats["elo_a"] = float(row["elo_before_w"])
            feats["elo_b"] = float(row["elo_before_l"])
            feats["elo_surf_a"] = float(row["elo_surf_before_w"])
            feats["elo_surf_b"] = float(row["elo_surf_before_l"])
        if include_player_ids:
            feats["player_a_id"] = int(row["winner_id"])
            feats["player_b_id"] = int(row["loser_id"])
        if "winner_rank" in row and "loser_rank" in row and pd.notna(row["winner_rank"]) and pd.notna(row["loser_rank"]):
            feats["rank_diff"] = float(row["loser_rank"] - row["winner_rank"])
        else:
            feats["rank_diff"] = 0.0
        if include_h2h and "h2h_winrate_w" in row:
            feats["h2h_diff"] = row["h2h_winrate_w"] - row["h2h_winrate_l"]
        return feats

    rows = []
    for _, r in matches.iterrows():
        base = build_diff_row(r)
        rows.append(base)
        mirror: dict = {"label": 0}
        if include_elo_levels:
            mirror["elo_a"] = base["elo_b"]
            mirror["elo_b"] = base["elo_a"]
            mirror["elo_surf_a"] = base["elo_surf_b"]
            mirror["elo_surf_b"] = base["elo_surf_a"]
        if include_player_ids:
            mirror["player_a_id"] = base["player_b_id"]
            mirror["player_b_id"] = base["player_a_id"]
        for k, v in base.items():
            if k == "label":
                continue
            if k in pair_keys:
                continue
            if k.endswith("_diff"):
                mirror[k] = -v
            else:
                mirror[k] = v
        rows.append(mirror)

    df_model = pd.DataFrame(rows).dropna().reset_index(drop=True)
    features = [c for c in df_model.columns if c != "label"]
    return df_model, features
