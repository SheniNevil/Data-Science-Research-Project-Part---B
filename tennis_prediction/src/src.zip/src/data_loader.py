"""
Load ATP match data from data/raw/ (tennis_atp-master or flat CSVs).
Supports subsetting by year range or max_rows for large datasets.
"""
from pathlib import Path
import re
import pandas as pd


# Main-tour singles: atp_matches_YYYY.csv (exclude _doubles, _futures, _qual_chall, _amateur)
MAIN_TOUR_PATTERN = re.compile(r"^atp_matches_(\d{4})\.csv$")


def find_main_tour_csvs(data_dir: Path) -> list[tuple[int, Path]]:
    """Find main-tour singles CSVs in data_dir. Returns list of (year, path)."""
    out = []
    if not data_dir.exists():
        return out
    for f in data_dir.iterdir():
        if not f.is_file() or not f.suffix == ".csv":
            continue
        m = MAIN_TOUR_PATTERN.match(f.name)
        if m:
            out.append((int(m.group(1)), f))
    return sorted(out, key=lambda x: x[0])


def load_atp_matches(
    raw_dir: Path | str = None,
    tennis_atp_subdir: str = "tennis_atp-master",
    year_min: int | None = None,
    year_max: int | None = None,
    max_rows: int | None = None,
) -> pd.DataFrame:
    """
    Load main-tour ATP match CSVs from raw_dir.

    - raw_dir: base dir (default: data/raw from project root).
    - tennis_atp_subdir: subfolder name for Sackmann repo (e.g. tennis_atp-master).
    - year_min, year_max: include only files atp_matches_YYYY.csv where year_min <= YYYY <= year_max.
    - max_rows: if set, keep only the last max_rows matches chronologically (for quick runs).

    Returns a single DataFrame sorted by tourney_date.
    """
    raw_dir = Path(raw_dir) if raw_dir else Path("data/raw")
    raw_dir = raw_dir.resolve()

    # Prefer tennis_atp-master subfolder
    subdir = raw_dir / tennis_atp_subdir
    if subdir.exists():
        year_paths = find_main_tour_csvs(subdir)
    else:
        year_paths = find_main_tour_csvs(raw_dir)

    if not year_paths:
        return pd.DataFrame()

    if year_min is not None:
        year_paths = [(y, p) for y, p in year_paths if y >= year_min]
    if year_max is not None:
        year_paths = [(y, p) for y, p in year_paths if y <= year_max]

    if not year_paths:
        return pd.DataFrame()

    dfs = []
    for _year, path in year_paths:
        try:
            df = pd.read_csv(path, low_memory=False)
            dfs.append(df)
        except Exception as e:
            raise RuntimeError(f"Failed to read {path}: {e}") from e

    out = pd.concat(dfs, ignore_index=True)

    # Ensure we have a date-like column for sorting
    date_col = "tourney_date"
    if date_col not in out.columns:
        for c in out.columns:
            if "date" in c.lower():
                out = out.rename(columns={c: date_col})
                break
    if date_col in out.columns:
        # Sort chronologically
        out[date_col] = pd.to_numeric(out[date_col], errors="coerce")
        out = out.dropna(subset=[date_col])
        out = out.sort_values(date_col).reset_index(drop=True)

    if max_rows is not None and len(out) > max_rows:
        out = out.tail(max_rows).reset_index(drop=True)

    return out
