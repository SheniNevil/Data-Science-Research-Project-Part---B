"""
Canonicalize column names and clean ATP match data (dates, surface, ranks, player IDs).
"""
from __future__ import annotations

import zlib

import pandas as pd

# Synthetic IDs when ATP winner_id/loser_id is missing (early years in some extracts).
# Range does not overlap typical Jeff Sackmann ATP id magnitudes in modern files.
_SYNTHETIC_ID_OFFSET = 1_000_000_000


def synthetic_player_id(name: str | float | None) -> int:
    """Deterministic surrogate id from normalized name when official id is absent."""
    if name is None or (isinstance(name, float) and pd.isna(name)) or str(name).strip() == "":
        return _SYNTHETIC_ID_OFFSET
    s = str(name).strip().lower()
    h = zlib.crc32(s.encode("utf-8")) & 0x7FFFFFFF
    return _SYNTHETIC_ID_OFFSET + h


def canonicalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Map common Sackmann column name variants to a standard set."""
    col_map = {}
    mapping_candidates = {
        "tourney_date": ["tourney_date", "tourney_date"],
        "surface": ["surface"],
        "winner_name": ["winner_name", "winner"],
        "loser_name": ["loser_name", "loser"],
        "winner_rank": ["winner_rank", "wrank", "winner_rank"],
        "loser_rank": ["loser_rank", "lrank", "loser_rank"],
        "winner_id": ["winner_id"],
        "loser_id": ["loser_id"],
        "score": ["score"],
    }
    for target, candidates in mapping_candidates.items():
        for c in candidates:
            if c in df.columns:
                col_map[c] = target
                break
    return df.rename(columns=col_map)


def clean_matches(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean match DataFrame: canonicalize columns, parse dates, normalize surface,
    coerce ranks, drop invalid rows, sort by date.
    """
    df = canonicalize_columns(df.copy())
    if "tourney_date" not in df.columns:
        for c in df.columns:
            if "date" in c.lower():
                df = df.rename(columns={c: "tourney_date"})
                break
    if "tourney_date" not in df.columns:
        return df

    # Support both YYYYMMDD int and YYYY-MM-DD string
    date_ser = df["tourney_date"]
    if date_ser.dtype.kind in "iu":
        df["tourney_date"] = pd.to_datetime(date_ser.astype(str), format="%Y%m%d", errors="coerce")
    else:
        df["tourney_date"] = pd.to_datetime(date_ser, format="mixed", errors="coerce")
    df = df.dropna(subset=["tourney_date", "winner_name", "loser_name"])

    df["surface"] = (
        df["surface"]
        .fillna("Unknown")
        .astype(str)
        .str.lower()
        .map(
            lambda s: "hard"
            if "hard" in s
            else ("clay" if "clay" in s else ("grass" if "grass" in s else "other"))
        )
    )

    for col in ["winner_rank", "loser_rank"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Official ATP-style ids when present; otherwise name-based synthetic (documented policy).
    for col, name_col in (("winner_id", "winner_name"), ("loser_id", "loser_name")):
        if col not in df.columns:
            df[col] = df[name_col].map(synthetic_player_id)
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")
            mask = df[col].isna()
            if mask.any():
                df.loc[mask, col] = df.loc[mask, name_col].map(synthetic_player_id)
            df[col] = df[col].astype(int)

    return df.sort_values("tourney_date").reset_index(drop=True)
